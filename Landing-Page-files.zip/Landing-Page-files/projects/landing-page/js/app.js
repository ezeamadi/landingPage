/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/

/**
 * Define Global Variables * 
*/

const sections = document.querySelectorAll('section');

const navbar = document.querySelector('#navbar__list');

/**
 * End Global Variables
 * Start Helper Functions
*/

const isInViewport = (elem) => {
	const bounding = elem.getBoundingClientRect();
	return (
		bounding.top >= 0 &&
		bounding.left >= 0 &&
		bounding.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
		bounding.right <= (window.innerWidth || document.documentElement.clientWidth)
	);
};

/**
 * End Helper Functions
 * Begin Main Functions
*/

let counter = 1;
// build the nav

sections.forEach((section) => {
	let navMenu = document.createElement('li');
	let anchor = document.createElement('a');

	anchor.href = `#${section.id}`;
	anchor.innerText = section.dataset.nav;
	anchor.classList.add('menu__link');
	anchor.id = 'navigation-tab-' + counter;

	// Click event
	anchor.onclick = () => {
		const activeElements = document.querySelectorAll('.active');

		activeElements.forEach((elem) => elem.classList.remove('active'));

		anchor.classList.add('active');

		section.classList.add('your-active-class');
	};

	// Build navbar
	navMenu.appendChild(anchor);
	navbar.appendChild(navMenu);
	counter++;
});

// When the user clicks on the button, scroll to the top of the document

const myButton = document.getElementById('myBtn');

function topFunction() {
	document.body.scrollIntoView({ behavior: 'smooth' });
	document.documentElement.scrollIntoView({ behavior: 'smooth' });
}

// addEvent();

let activeTab = -1;
window.addEventListener('scroll', function scrolling() {
	sections.forEach((section) => {
		if (isInViewport(section)) {
			section.classList.add('your-active-class');
			document.getElementById('navigation-tab-' + section.id.slice(-1)).classList.remove('active');
			document.getElementById('navigation-tab-' + section.id.slice(-1)).classList.add('active');
		} else {
			section.classList.remove('your-active-class');

			// grab numerical value of current hovered section/tab.
			activeTab = section.id.slice(-1);

			// Go through every section and remove .current-hover,
			// except for what is currently being hovered.
			if (document.getElementById('navigation-tab-' + section.id.slice(-1)) != activeTab) {
				document.getElementById('navigation-tab-' + activeTab).classList.remove('active');
			}
		}
	});
});
