# Landing Page Project

## Table of Contents

* [Instructions](#instructions)

## Instructions

The app.js contains the code for the dynamic navigation bar. 
It also removes the navbar when scrolling occurs and sets an 
active class when page is in viewport.
